javac -d ./bin ./src/*.java
cd bin
java Main
cd ..

