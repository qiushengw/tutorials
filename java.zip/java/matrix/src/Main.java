
public class Main {

    public static int[][] turn(int[][] matrix){
        int orgMaxRowIndex = matrix.length-1;
        int orgMaxColIndex = matrix[0].length-1;

        int[][] newMatrix = new int[matrix[0].length-1][matrix.length];
         
        for(int i=0;i<=orgMaxRowIndex;i++){
            for(int j = 0;j<=orgMaxColIndex;j++){
                newMatrix[j][orgMaxRowIndex-i] = matrix[i][j];
            }
        }

        return newMatrix;
    }



    public static void main(String[] args){
        int[][] input = {
            {1,2,3},
            {4,5,6},
            {7,8,9}
        };
    

    int[][] ret = turn(input);

    for(int i=0;i<ret.length;i++){
        for(int j=0;j<ret[0].length;j++){
            System.out.print(ret[i][j]+",");
        }
        System.out.println();
    }
    }

}